import css from "./style.styl"
console.log(`Webpack is loaded successfully`);