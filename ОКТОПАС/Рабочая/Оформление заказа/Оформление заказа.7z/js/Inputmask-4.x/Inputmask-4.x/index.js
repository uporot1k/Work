require("./dist/inputmask/inputmask.extensions");
require("./dist/inputmask/inputmask.date.extensions");
require("./dist/inputmask/inputmask.numeric.extensions");

module.exports = require("./dist/inputmask/inputmask.js");
