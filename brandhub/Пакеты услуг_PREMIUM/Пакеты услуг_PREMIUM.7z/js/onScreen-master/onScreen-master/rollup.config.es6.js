import config from './rollup.config';

config.format = 'es';
config.dest = 'dist/on-screen.es6.js';

export default config;
